package com.yuanshenwiki.yuanshenwiki.util;

public enum UserType {

    Leader,Administrator,User;

}
