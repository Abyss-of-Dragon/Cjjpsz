package com.yuanshenwiki.yuanshenwiki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuanshenwikiApplicationTests {

    @Test
    void contextLoads() {
    }

}
