package decorator;

public class Test {
	public static void main(String[] args) {
		Phone p=new ordinaryPhone();
		p=new smartPhone(p);
		p.call();
	}
}
