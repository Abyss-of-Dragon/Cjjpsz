package decorator;

public interface Phone {
	 public  void call();
}
