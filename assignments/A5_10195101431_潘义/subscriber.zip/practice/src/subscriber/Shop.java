package subscriber;

import java.util.ArrayList;

public class Shop implements Subject {
    private ArrayList<Observer> customerList;
    private ArrayList<String> messages;
 
    public Shop() {
        customerList = new ArrayList<>();
        messages = new ArrayList<>();
    }
 
    public void registerObserver(Observer observer) {
        customerList.add(observer);
    }
 
    public void removeObserver(Observer observer) {
 
    }
 
    public void notifyAllObservers() {
        for (Observer observer : customerList) {
            observer.update(this);
        }
    }
 
    public void postMessage(String message) {
        this.messages.add(message);
        notifyAllObservers();
    }
 
    public ArrayList<String> getMessages() {
        return messages;
    }
 
    public String toString() {
        return messages.toString();
    }
}
