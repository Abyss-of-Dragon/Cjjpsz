package command;

public interface Order {
    void execute();
}