package command;

public class Stock {
	private String name ="XXX��Ʊ";
    private int quantity =100;
 
    public void buy(){
        System.out.println("���"+name+quantity+"��");
    }
 
    public void sell(){
        System.out.println("����"+name+quantity+"��");
    }
}
