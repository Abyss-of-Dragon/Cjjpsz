package proxy;

import proxy.Printable;
import proxy.Printer;
import proxy.PrinterProxy;

interface Printable {

    void setPrinterName(String name);

    String getPrinterName();

    void print(String string);
}

class PrinterProxy implements Printable {

    private String name;

    private Printer real;

    public PrinterProxy(String name) {
        this.name = name;
    }

    public synchronized void setPrinterName(String name) {
        if (this.real != null) {
            this.real.setPrinterName(name);
        }
        this.name = name;
    }

 
    public String getPrinterName() {
        return this.name;
    }

    public void print(String string) {
        this.realize();
        this.real.print(string);
    }

    private synchronized void realize() {
        if (this.real == null) {
            this.real = new Printer(this.name);
        }
    }
}



class Printer implements Printable {

    private String name;

    public Printer() {
        this.heavyJob("��������Printer��ʵ��");
    }

    public Printer(String name) {
        this.name = name;
        this.heavyJob("��������Printer��ʵ��(" + this.name + ")");
    }


    public void setPrinterName(String name) {
        this.name = name;
    }


    public String getPrinterName() {
        return this.name;
    }

    public void print(String string) {
        System.out.println("===" + this.name + "===");
        System.out.println(string);
    }


    private void heavyJob(String msg) {
        System.out.print(msg);
        for (int i = 0; i < 5; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.print(".");
        }
        System.out.println("������");
    }
}


public class ProxyPattern {
public static void main(String[] args) {
        Printable p = new PrinterProxy("lab5");
        System.out.println("���ڵ�������" + p.getPrinterName() + "��");
        p.setPrinterName("lab5");
        System.out.println("���ڵ�������" + p.getPrinterName() + "��");
        p.print("software engineering.");
    }
}
