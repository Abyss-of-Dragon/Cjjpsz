package command;

public class TVCloseCommand implements AbstractCommand {

    private Televison tv;

    public TVCloseCommand() {

        tv = new Televison();
    }

    @Override
    public void execute() {
        tv.close();
    }
}
