package command;

public class Televison {

    public void open() {
        System.out.println("lab5");
    }

    public void close() {
        System.out.println("software engineering");
    }

    public void changeChannel() {
        System.out.println("lab");
    }
}
