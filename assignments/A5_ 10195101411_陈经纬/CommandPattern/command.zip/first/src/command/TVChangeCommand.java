package command;

public class TVChangeCommand implements AbstractCommand {

    private Televison tv;

    public TVChangeCommand() {

        tv = new Televison();
    }

    @Override
    public void execute() {
        tv.changeChannel();
    }
}
