package command;

public class TVOpenCommand implements AbstractCommand {

    private Televison tv;

    public TVOpenCommand() {

        tv = new Televison();
    }

    @Override
    public void execute() {
        tv.open();
    }
}
